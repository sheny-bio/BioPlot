#####目前建议使用的R版本 3.5.3（该版本稳定性和包的兼容性较好）  4.0.3-4.0.5
rm(list=ls())

############library R packages#############
######括号内填写载入需要的R包########
library(openxlsx)
library(swimplot)
library(ggplot2)
library(ggpubr)

##############set working dirctory#################
##############需要修改：设置工作路径（即引号内填写所有输入文件和输出文件所在的默认文件夹位置）######
file_path <- 'D:/projects/codingTraining/6.swimmer_plot'
############输入输出文件参数#####################################
############input file parameters#####################################
##############set input data for a bar graph###################################
##############需要修改：柱状图数据文件，引号内填写输入文件名########
input_for_plotting_bars <- "bar_plot.xlsx"
##############set input data for a bar graph###################################
##############需要修改：点图数据文件，引号内填写输入文件名##############
input_for_plotting_dots <- "dot_plot.xlsx"
##############set input data for a bar graph###################################
##############需要修改：点图数据文件，引号内填写输入文件名##############
input_for_adding_lines <- "line_plot.xlsx"


############output file parameters#####################################
##############set output file name###################
##############设置输出文件名#########################
out_fig_name <- "swimmer plot.pdf"
##############set the width of output graph###
##############可以自定义：输出文件宽度########
set_fig_width <- 15
##############set the height of output graph###
##############可以自定义：输出文件高度#########
set_fig_height <- 10



###########set parameters for bar graph############
###########需要修改：柱状图数据及图形外观参数#########
###########be the column name for id########################################
###########需要修改：柱状图输入文件第一列列名(患者名，样本名等)#############
set_id_for_bar_graph <- 'Patient_ID'
###########be the column name to map the bar fill####################################
###########需要修改：柱状图输入文件第二列列名(每个线段代表的内容：治疗方式/疗效评价等)########
set_entity_of_bars <- 'Treatment'
###########be the column name to map endpoints for each bar###################
###########需要修改：柱状图输入文件第三列列名(每个线段的截止位置)#############
set_endpoint_of_bars <- 'End_trt'


###########set parameters for dot graph#############
###########需要修改：点图数据及图形外观参数#########
###########be the name of the first column################################
###########需要修改：点图输入文件第一列列名(患者名，样本名等)#############
set_id_for_dot_graph <- 'Patient_ID'
############a column name to map the point shape#################################
############需要修改：点图输入文件第二列列名(点图事件类型)#######################
set_entity_of_dots <- 'Event'
############a column name to map the point shape###################
############需要修改：点图输入文件第三列列名(点图事件状态)#########
set_condition_of_dots <- "Related"
###########be the column name with the point locations########################
###########需要修改：点图输入文件第四列列名(每个点的位置)#####################
set_location_of_dots <- 'Time'
###########set the size of each dot###################
###########可以自定义：设置点的大小#####################
set_dot_size <- 2.5


###########input data for lines on the bar#########
###########需要修改：增加线段数据输入##############
###########be the name of the first column##########################################
###########需要修改：增加线段信息的输入文件第一列列名(患者名，样本名等)#############
set_id_for_adding_lines <- 'Patient_ID'
###########be the column name to map start points for each line###########################
###########需要修改：增加线段信息的输入文件第二列列名(线段表示的状态)#################
set_entity_of_lines <- 'Response'
###########be the column name to map start points for each line###########################
###########需要修改：增加线段信息的输入文件第三列列名(每条线段的起始位置)#################
set_startpoint_of_lines <- 'Relapse_start'
###########be the column name to map start points for each line###########################
###########需要修改：增加线段信息的输入文件第四列列名(每条线段的终止位置)#################
set_endpoint_of_lines <- 'End_follow_up'



########################################################################################


###########set parameters for bar graph2 ############
###########可以自定义：柱状图数据及图形外观参数2 #########
###########set the order of bars############
###########可以自定义：设置柱子的顺序。#########
if(FALSE){
  "默认：NULL,即按照总随访时间从高到低分布；"
  "可选1：增加分组列，则此处为分组列的列名；"
  "可选2：人为固定顺序，比如c('P01','P02','P03','P04','P05','P06'),设置泳图顺序按照患者编号从p01到p06排列"
}
set_bar_order <- NULL
###########set the color of the stroke of the bars, set as black by default############
###########可以自定义：设置柱子的边框颜色，默认参数为黑色##############################
set_bar_stroke_color <- "black"
###########set the outline of the bars############
###########可以自定义：设置柱子的宽度#############
set_bar_width <- 0.2
###########set the transparency of the bars############
###########可以自定义：设置柱子颜色的透明度############
set_bar_transparency <- 0.75
###########set bar colors############
###########可以自定义：设置柱子颜色。可选："DEFAULT”（默认配色）；或者手动定义每种线段的配色,如示例输入文件中：c("Concurrent_chemoradiotherapy" = "#e41a1c", "Adjuvant_chemotherapy" = "#377eb8","Break_between_cycles" = "#808080", "Follow_up" = "#4daf4a")############
set_bar_color = "DEFAULT"

###########set parameters for arrows ############
###########可以自定义：箭头外观参数 #############
###########mapping the arrows to the bars############
###########可以自定义:增加箭头,箭头信息列############
add_arrows <- "Continued_treatment"
###########set arrow length， 0.1 by default#######################
###########可以自定义:设置箭头的长度，默认0.1######################
set_arrows_length <- 0.1
###########set the style of arrows （"open", "closed"）#################
###########可以自定义:选择箭头的样式，可选："open", "closed"############
set_arrows_style <- "closed"
###########set arrow size#######################
###########可以自定义:设置箭头的大小############
set_arrows_size <- 0.2
###########set the angle of arrows #############
###########可以自定义:设置箭头的角度############
set_arrows_angle <- 30

###########set parameters for dots ############
###########可以自定义：点图外观参数 #############
###########set dot colors############
###########可以自定义：设置点颜色。可选："DEFAULT”（默认配色）；或者手动定义每种点的配色,如示例输入文件中：c("positive" = "#2c7fb8", "negative" = "#7fcdbb")############
set_dot_color <- "DEFAULT"

###########set parameters for lines ############
###########可以自定义：增加线段的外观参数 ######
###########set line colors###########################
###########可以自定义：设置线段粗细。默认为1 ########
set_line_size <- 2






##############input data############################
plotting_bars <- read.xlsx(input_for_plotting_bars,colNames = T)
plotting_dots <- read.xlsx(input_for_plotting_dots,colNames = T)
plotting_lines <- read.xlsx(input_for_adding_lines,colNames = T)

#################set working directory###############
setwd(file_path)


#####################plotting graphs#################

#1.plotting bar graphs
bar_plot <- swimmer_plot(df = plotting_bars,
                         id = set_id_for_bar_graph,
                         end = set_endpoint_of_bars,
                         name_fill = set_entity_of_bars,
                         id_order = set_bar_order,
                         col = set_bar_stroke_color,
                         alpha = set_bar_transparency,
                         width = set_bar_width) 

##modifying color and shape
if (toString(set_bar_color) != "DEFAULT"){
  bar_plot <- bar_plot + ggplot2::scale_fill_manual(name = set_entity_of_bars,
                                                    values = set_bar_color) 
}else{
  bar_plot <- bar_plot
}

#bar_plot


#2.plotting dot graphs
bar_with_dot_plot <- bar_plot + swimmer_points(df_points = plotting_dots,
                                               id = set_id_for_dot_graph,
                                               time = set_location_of_dots,
                                               name_shape = set_entity_of_dots,
                                               size = set_dot_size,
                                               fill = 'white',
                                               name_col = set_condition_of_dots) 
bar_with_dot_plot

##modifying color and shape
if (toString(set_dot_color) != "DEFAULT"){
  bar_with_dot_plot <- bar_with_dot_plot +
    ggplot2::scale_color_manual(name = set_entity_of_dots,
                                values = set_dot_color)  +
    ggplot2::scale_shape_manual(name = set_condition_of_dots, 
                                values = c(positive = 21, negative = 24))
}else{
  bar_with_dot_plot <- bar_with_dot_plot
}

bar_with_dot_plot


#3.plotting arrows
if (add_arrows %in% colnames(plotting_bars))
{
  bar_with_dot_with_arrow_plot <- bar_with_dot_plot + swimmer_arrows(df_arrows = plotting_bars,
                                                                     id = set_id_for_bar_graph,
                                                                     arrow_start = set_endpoint_of_bars,
                                                                     cont = add_arrows,
                                                                     length = set_arrows_length,
                                                                     #name_col = "Group",
                                                                     angle = set_arrows_angle,
                                                                     cex = set_arrows_size,
                                                                     type = set_arrows_style)
  #  + scale_color_discrete(drop=FALSE)   #work with groups 
}else{
  bar_with_dot_with_arrow_plot <- bar_with_dot_plot
}

bar_with_dot_with_arrow_plot

#4.adding lines

final_plot <- bar_with_dot_with_arrow_plot + swimmer_lines(df = plotting_lines,
                                                           id = set_id_for_adding_lines,
                                                           start = set_startpoint_of_lines,
                                                           end = set_endpoint_of_lines,
                                                           name_col = set_entity_of_lines,
                                                           size = set_line_size) 
final_plot



#export the plot
ggexport(final_plot,
         width = set_fig_width,
         height = set_fig_height,
         filename = out_fig_name,
         device = "pdf")

